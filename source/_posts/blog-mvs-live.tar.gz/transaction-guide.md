---
title: 元界钱包转账操作详解
date: June 20, 2017 7:00 PM
tags: Metaverse
categories: Guide
---

如需将ETP从元界钱包转到其他地址，请按照如下操作进行：

首先在左侧导航栏选择“我的资产”>>“ETP”

![1](http://bbs.viewfin.com/data/attachment/forum/201706/01/144848vdh5drn1xb59dn9d.png)

右侧则会出现如下图所示的转账界面，按照下图黄字所示输入信息，点击“确认转移”，即可转账。

![2](http://bbs.viewfin.com/data/attachment/forum/201706/01/145156f8ia9a1t4l56tk88.png)

交易区显示你所进行的转账交易记录

![3](http://bbs.viewfin.com/data/attachment/forum/201706/01/145409gf7puh74zpunb9tx.png)

红色箭头表示这笔交易是从元界钱包转出ETP，绿色表示这笔交易是ETP从别处转入到你的元界钱包。


