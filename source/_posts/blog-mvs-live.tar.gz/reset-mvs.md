---
title: How To Reset Metaverse Environment?
date: 2017-04-18 13:44:21
tags: Metaverse
categories: Guide
---

<font color="#FF0000"> <b>CAUTION: PLEASE BACKUP YOUR ACCOUNT's MNEMONIC-PHRASE OF MASTER-KEY AT FIRST.
注意: 请在做重置操作前备份好您所有账户的主私钥助记符（即注册账户时生成的24个单词）。
</b></font> 


Please copy and paste the below into the search function on your device:
Windows
-------------
```
%HOMEPATH%\AppData\Roaming\Metaverse
```

Mac-OSX
-------------
```
~/Library/Application\ Support/Metaverse
```

Linux(unix-like):
-------------
```
~/.metaverse
```
Delete the Metaverse folder, then start up 'mvsd'.
移除（重命名）该文件夹，然后启动mvsd.


